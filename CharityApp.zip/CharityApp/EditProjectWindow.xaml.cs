﻿using CharityApp.models;
using Microsoft.Win32;
using System;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace CharityApp
{
    public partial class EditProjectWindow : Window
    {
        private Project _project;
        public string ImagePath { get; set; }

        public EditProjectWindow(Project projectToEdit)
        {
            InitializeComponent();
            _project = projectToEdit;

            CategoryComboBox.Items.Clear();

            using (var context = new CharityDbContext())
            {
                var categories = context.Categories.ToList();
                CategoryComboBox.ItemsSource = categories;
                CategoryComboBox.DisplayMemberPath = "Name";
                CategoryComboBox.SelectedItem = categories.FirstOrDefault(c => c.Id == _project.CategoryId);
            }

            TitleBox.Text = _project.Title;
            FullTitleBox.Text = _project.FullTitle;
            DescriptionBox.Text = _project.Description;
            TargetAmountBox.Text = _project.GoalAmount.ToString(CultureInfo.InvariantCulture);
            EndDatePicker.SelectedDate = _project.EndDate;
            ImagePath = _project.ImagePath;
        }

        private void NumberValidationTextBox(object sender, TextCompositionEventArgs e)
        {
            if (!char.IsDigit(e.Text, 0))
            {
                if (e.Text != "." && e.Text != ",")
                {
                    e.Handled = true;
                    return;
                }

                if (((TextBox)sender).Text.Contains(".") || ((TextBox)sender).Text.Contains(","))
                {
                    e.Handled = true;
                }
            }
        }

        private void UploadImage_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog
            {
                Title = "Выберите новое изображение",
                Filter = "Изображения (*.png;*.jpg;*.jpeg)|*.png;*.jpg;*.jpeg"
            };

            if (dialog.ShowDialog() == true)
            {
                ImagePath = dialog.FileName;
                MessageBox.Show("Изображение обновлено:\n" + ImagePath);
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (!decimal.TryParse(TargetAmountBox.Text, NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture, out decimal goalAmount))
            {
                MessageBox.Show("Целевая сумма должна быть числом.");
                return;
            }

            if (CategoryComboBox.SelectedItem is not Category selectedCategory)
            {
                MessageBox.Show("Пожалуйста, выберите категорию.");
                return;
            }

            using (var context = new CharityDbContext())
            {
                var projectInDb = context.Projects.FirstOrDefault(p => p.Id == _project.Id);
                if (projectInDb == null)
                {
                    MessageBox.Show("Проект не найден в базе данных.");
                    return;
                }

                projectInDb.Title = TitleBox.Text.Trim();
                projectInDb.FullTitle = FullTitleBox.Text.Trim();
                projectInDb.Description = DescriptionBox.Text.Trim();
                projectInDb.GoalAmount = goalAmount;
                projectInDb.EndDate = EndDatePicker.SelectedDate ?? DateTime.Today;
                projectInDb.ImagePath = ImagePath;
                projectInDb.CategoryId = selectedCategory.Id;

                context.SaveChanges();
            }

            MessageBox.Show("Проект успешно обновлён.");
            this.DialogResult = true;
            this.Close();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
            this.Close();
        }
    }
}