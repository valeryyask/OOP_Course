﻿using System.Linq;
using System.Windows;
using CharityApp.models;
using Microsoft.EntityFrameworkCore;

namespace CharityApp
{
    public partial class VolunteerApplicationsWindow : Window
    {
        private class ApplicationViewModel
        {
            public int Id { get; set; }
            public string Username { get; set; }
            public string ProjectTitle { get; set; }
            public string Motivation { get; set; }
            public string Status { get; set; }
        }

        public VolunteerApplicationsWindow()
        {
            InitializeComponent();
            LoadApplications();
        }

        private void LoadApplications()
        {
            using (var context = new CharityDbContext())
            {
                var applications = context.VolunteerApplications
                    .Include(a => a.User)
                    .Include(a => a.Project)
                    .Select(a => new ApplicationViewModel
                    {
                        Id = a.Id,
                        Username = a.User != null ? a.User.Username : "Не указан",
                        ProjectTitle = a.Project != null ? a.Project.Title : "Не указан",
                        Motivation = a.Motivation ?? "Нет мотивации",
                        Status = a.Status ?? "Не определён"
                    })
                    .ToList();

                System.Diagnostics.Debug.WriteLine("Loaded Applications: " + string.Join(", ", applications.Select(a => $"{a.Username} - {a.ProjectTitle}")));
                ApplicationsList.ItemsSource = applications;
            }
        }

        private void ApproveApplication_Click(object sender, RoutedEventArgs e)
        {
            if (ApplicationsList.SelectedItem is ApplicationViewModel selected)
            {
                using (var context = new CharityDbContext())
                {
                    var application = context.VolunteerApplications
                        .Include(a => a.User)
                        .Include(a => a.Project)
                        .FirstOrDefault(a => a.Id == selected.Id);

                    if (application != null)
                    {
                        application.Status = "Approved";

                        var existingVolunteer = context.Volunteers
                            .FirstOrDefault(v => v.UserId == application.UserId && v.ProjectId == application.ProjectId);

                        if (existingVolunteer == null)
                        {
                            var newVolunteer = new Volunteer
                            {
                                UserId = application.UserId,
                                ProjectId = application.ProjectId,
                                IsBlocked = false,
                                RoleInProject = "Volunteer" 
                            };
                            System.Diagnostics.Debug.WriteLine($"New Volunteer: UserId={newVolunteer.UserId}, ProjectId={newVolunteer.ProjectId}, RoleInProject={newVolunteer.RoleInProject}");
                            context.Volunteers.Add(newVolunteer);
                        }

                        context.SaveChanges();
                        MessageBox.Show($"Заявка от {selected.Username} одобрена.");
                        LoadApplications();
                    }
                    else
                    {
                        MessageBox.Show("Заявка не найдена.");
                    }
                }
            }
        }

        private void RejectApplication_Click(object sender, RoutedEventArgs e)
        {
            if (ApplicationsList.SelectedItem is ApplicationViewModel selected)
            {
                using (var context = new CharityDbContext())
                {
                    var application = context.VolunteerApplications.Find(selected.Id);
                    if (application != null)
                    {
                        application.Status = "Rejected";
                        context.SaveChanges();
                        MessageBox.Show($"Заявка от {selected.Username} отклонена.");
                        LoadApplications();
                    }
                    else
                    {
                        MessageBox.Show("Заявка не найдена.");
                    }
                }
            }
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}