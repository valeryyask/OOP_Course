﻿using CharityApp.models;
using Microsoft.EntityFrameworkCore;
using System;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media.Imaging;

namespace CharityApp
{
    public partial class ProjectDetailsWindow : Window, INotifyPropertyChanged
    {
        private readonly Project _project;
        private readonly User _currentUser;
        private bool _canEditProject;

        public User CurrentUser => _currentUser;
        public Project Project => _project;

        public event PropertyChangedEventHandler PropertyChanged;

        public bool CanEditProject
        {
            get => _canEditProject;
            private set
            {
                _canEditProject = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(CanEditProject)));
            }
        }

        public ProjectDetailsWindow(Project project, User currentUser)
        {
            InitializeComponent();
            _project = project ?? throw new ArgumentNullException(nameof(project));
            _currentUser = currentUser ?? throw new ArgumentNullException(nameof(currentUser));
            System.Diagnostics.Debug.WriteLine($"ProjectDetailsWindow: UserId={_currentUser.Id}, Username={_currentUser.Username}, ProjectId={_project.Id}, Role={_currentUser.Role}");
            DataContext = _project;
            UpdateCanEditProject();
            LoadProjectData();
        }

        private void UpdateCanEditProject()
        {
            System.Diagnostics.Debug.WriteLine($"UpdateCanEditProject: UserId={_currentUser.Id}, Role={_currentUser.Role}");
            if (_currentUser.Role == "Admin")
            {
                CanEditProject = true;
            }
            else
            {
                using (var context = new CharityDbContext())
                {
                    CanEditProject = context.Volunteers
                        .Any(v => v.UserId == _currentUser.Id && v.ProjectId == _project.Id && !v.IsBlocked);
                    System.Diagnostics.Debug.WriteLine($"UpdateCanEditProject: CanEditProject={CanEditProject}");
                }
            }
        }

        private void LoadProjectData()
        {
            try
            {
                using (var context = new CharityDbContext())
                {
                    System.Diagnostics.Debug.WriteLine($"LoadProjectData: Loading project with ProjectId={_project.Id}");
                    var project = context.Projects
                        .Include(p => p.Category)
                        .Include(p => p.Status)
                        .Include(p => p.Reviews)
                        .ThenInclude(r => r.User)
                        .FirstOrDefault(p => p.Id == _project.Id);

                    if (project == null)
                    {
                        System.Diagnostics.Debug.WriteLine($"LoadProjectData: Project not found for ProjectId={_project.Id}");
                        MessageBox.Show("Проект не найден.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                        Close();
                        return;
                    }

                    _project.Title = project.Title;
                    _project.FullTitle = project.FullTitle;
                    _project.Description = project.Description;
                    _project.Category = project.Category;
                    _project.Status = project.Status;
                    _project.EndDate = project.EndDate;
                    _project.GoalAmount = project.GoalAmount;
                    _project.CollectedAmount = project.CollectedAmount;
                    _project.ImagePath = project.ImagePath;
                    _project.Reviews = project.Reviews;

                    DataContext = _project;

                    ReviewsList.ItemsSource = _project.Reviews?.OrderByDescending(r => r.CreatedAt).ToList();
                    System.Diagnostics.Debug.WriteLine($"LoadProjectData: Loaded {(_project.Reviews?.Count ?? 0)} reviews");
                    foreach (var review in _project.Reviews ?? Enumerable.Empty<Review>())
                    {
                        System.Diagnostics.Debug.WriteLine($"Review: Id={review.Id}, UserId={review.UserId}, Username={review.User?.Username}, Content={review.Content}");
                    }

                    if (!string.IsNullOrWhiteSpace(_project.ImagePath) && File.Exists(_project.ImagePath))
                    {
                        ProjectImage.Source = new BitmapImage(new Uri(_project.ImagePath));
                    }
                    else
                    {
                        ProjectImage.Source = null;
                        System.Diagnostics.Debug.WriteLine($"LoadProjectData: Image not found at path={_project.ImagePath}");
                    }
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"LoadProjectData: Error: {ex.Message}, StackTrace: {ex.StackTrace}");
                MessageBox.Show($"Ошибка при загрузке данных проекта: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Donate_Click(object sender, RoutedEventArgs e)
        {
            var donateWindow = new DonateWindow(_currentUser);
            if (donateWindow.ShowDialog() == true)
            {
                decimal amount = donateWindow.Amount;

                try
                {
                    using (var context = new CharityDbContext())
                    {
                        System.Diagnostics.Debug.WriteLine($"Donate_Click: UserId={_currentUser.Id}, ProjectId={_project.Id}, Amount={amount}");
                        var project = context.Projects.FirstOrDefault(p => p.Id == _project.Id);
                        if (project == null)
                        {
                            System.Diagnostics.Debug.WriteLine($"Donate_Click: Project not found for ProjectId={_project.Id}");
                            MessageBox.Show("Проект не найден.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                            return;
                        }

                        project.CollectedAmount += amount;

                        var donation = new Donation
                        {
                            Amount = amount,
                            Date = DateTime.Now,
                            ProjectId = project.Id,
                            UserId = _currentUser.Id
                        };

                        context.Donations.Add(donation);
                        int changes = context.SaveChanges();
                        System.Diagnostics.Debug.WriteLine($"Donate_Click: SaveChanges affected {changes} rows");

                        var savedDonation = context.Donations
                            .FirstOrDefault(d => d.UserId == _currentUser.Id && d.ProjectId == project.Id && d.Amount == amount && d.Date == donation.Date);
                        if (savedDonation == null)
                        {
                            System.Diagnostics.Debug.WriteLine($"Donate_Click: Donation not found after SaveChanges! UserId={_currentUser.Id}, ProjectId={project.Id}, Amount={amount}, Date={donation.Date}");
                        }
                        else
                        {
                            System.Diagnostics.Debug.WriteLine($"Donate_Click: Saved donation: Id={savedDonation.Id}, UserId={savedDonation.UserId}, ProjectId={savedDonation.ProjectId}, Amount={savedDonation.Amount}, Date={savedDonation.Date}");
                        }

                        var allDonations = context.Donations
                            .Where(d => d.UserId == _currentUser.Id)
                            .Select(d => new { d.ProjectId, d.Amount, d.Date })
                            .ToList();
                        System.Diagnostics.Debug.WriteLine($"Donate_Click: All donations for UserId={_currentUser.Id}: {string.Join("; ", allDonations.Select(d => $"ProjectId={d.ProjectId}, Amount={d.Amount}, Date={d.Date}"))}");

                        _project.CollectedAmount = project.CollectedAmount;
                        DataContext = _project;

                        MessageBox.Show($"Спасибо за пожертвование в {_project.Title} на сумму {amount} BYN!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"Donate_Click: Error: {ex.Message}, StackTrace: {ex.StackTrace}");
                    MessageBox.Show($"Ошибка при обработке пожертвования: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void Edit_Click(object sender, RoutedEventArgs e)
        {
            var editWindow = new EditProjectWindow(_project);
            if (editWindow.ShowDialog() == true)
            {
                LoadProjectData();
                UpdateCanEditProject();
            }
        }

        private void SubmitReview_Click(object sender, RoutedEventArgs e)
        {
            string reviewContent = ReviewTextBox.Text?.Trim();
            if (string.IsNullOrWhiteSpace(reviewContent))
            {
                MessageBox.Show("Пожалуйста, введите текст отзыва.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (reviewContent.Length > 500)
            {
                MessageBox.Show("Отзыв не должен превышать 500 символов.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                using (var context = new CharityDbContext())
                {
                    System.Diagnostics.Debug.WriteLine($"SubmitReview_Click: Checking donations for UserId={_currentUser.Id}, ProjectId={_project.Id}");
                    bool hasDonated = context.Donations
                        .Any(d => d.UserId == _currentUser.Id && d.ProjectId == _project.Id);
                    if (!hasDonated)
                    {
                        var donations = context.Donations
                            .Where(d => d.UserId == _currentUser.Id && d.ProjectId == _project.Id)
                            .ToList();
                        System.Diagnostics.Debug.WriteLine($"SubmitReview_Click: HasDonated={hasDonated}, UserId={_currentUser.Id}, ProjectId={_project.Id}, DonationsCount={donations.Count}");

                        var allDonations = context.Donations
                            .Where(d => d.UserId == _currentUser.Id)
                            .Select(d => new { d.ProjectId, d.Amount, d.Date })
                            .ToList();
                        System.Diagnostics.Debug.WriteLine($"SubmitReview_Click: All donations for UserId={_currentUser.Id}: {string.Join("; ", allDonations.Select(d => $"ProjectId={d.ProjectId}, Amount={d.Amount}, Date={d.Date}"))}");

                        MessageBox.Show("Оставлять отзывы могут только пользователи, сделавшие пожертвование.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                        return;
                    }

                    var review = new Review
                    {
                        Content = reviewContent,
                        UserId = _currentUser.Id,
                        ProjectId = _project.Id,
                        CreatedAt = DateTime.Now
                    };

                    context.Reviews.Add(review);
                    int changes = context.SaveChanges();
                    System.Diagnostics.Debug.WriteLine($"SubmitReview_Click: SaveChanges affected {changes} rows, New ReviewId={review.Id}");

                    ReviewTextBox.Text = "";
                    LoadProjectData();

                    MessageBox.Show("Отзыв успешно добавлен!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"SubmitReview_Click: Error: {ex.Message}, StackTrace: {ex.StackTrace}");
                MessageBox.Show($"Ошибка при добавлении отзыва: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void DeleteReview_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.Tag is int reviewId)
            {
                try
                {
                    using (var context = new CharityDbContext())
                    {
                        var review = context.Reviews
                            .Include(r => r.User)
                            .FirstOrDefault(r => r.Id == reviewId);

                        if (review == null)
                        {
                            System.Diagnostics.Debug.WriteLine($"DeleteReview_Click: Review not found for ReviewId={reviewId}");
                            MessageBox.Show("Отзыв не найден.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                            return;
                        }

                        bool isAdmin = _currentUser.Role == "Admin";
                        bool isReviewOwner = review.UserId == _currentUser.Id;
                        bool hasDonated = context.Donations
                            .Any(d => d.UserId == _currentUser.Id && d.ProjectId == _project.Id);

                        System.Diagnostics.Debug.WriteLine($"DeleteReview_Click: ReviewId={reviewId}, UserId={_currentUser.Id}, Username={_currentUser.Username}, ProjectId={_project.Id}, IsAdmin={isAdmin}, IsReviewOwner={isReviewOwner}, HasDonated={hasDonated}");

                        var allDonations = context.Donations
                            .Where(d => d.UserId == _currentUser.Id)
                            .Select(d => new { d.ProjectId, d.Amount, d.Date })
                            .ToList();
                        System.Diagnostics.Debug.WriteLine($"DeleteReview_Click: All donations for UserId={_currentUser.Id}: {string.Join("; ", allDonations.Select(d => $"ProjectId={d.ProjectId}, Amount={d.Amount}, Date={d.Date}"))}");

                        if (!isAdmin && !(isReviewOwner && hasDonated))
                        {
                            System.Diagnostics.Debug.WriteLine($"DeleteReview_Click: Permission denied for UserId={_currentUser.Id}, ReviewId={reviewId}");
                            MessageBox.Show("Вы не можете удалить этот отзыв. Удаление доступно только автору отзыва, сделавшему пожертвование, или администратору.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                            return;
                        }

                        context.Reviews.Remove(review);
                        int changes = context.SaveChanges();
                        System.Diagnostics.Debug.WriteLine($"DeleteReview_Click: SaveChanges affected {changes} rows for ReviewId={reviewId}");

                        LoadProjectData();
                        MessageBox.Show("Отзыв успешно удален!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"DeleteReview_Click: Error: {ex.Message}, StackTrace: {ex.StackTrace}");
                    MessageBox.Show($"Ошибка при удалении отзыва: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                System.Diagnostics.Debug.WriteLine($"DeleteReview_Click: Invalid sender or Tag. Sender={sender?.GetType().Name}, Tag={(sender as Button)?.Tag}");
            }
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }

    public class ReviewDeleteButtonVisibilityConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (value is Review review && parameter is ProjectDetailsWindow window)
            {
                var currentUser = window.CurrentUser;
                var projectId = window.Project.Id;

                bool isAdmin = currentUser.Role == "Admin";
                bool isReviewOwner = review.UserId == currentUser.Id;

                using (var context = new CharityDbContext())
                {
                    bool hasDonated = context.Donations
                        .Any(d => d.UserId == currentUser.Id && d.ProjectId == projectId);

                    System.Diagnostics.Debug.WriteLine($"ReviewDeleteButtonVisibilityConverter: ReviewId={review.Id}, UserId={currentUser.Id}, Username={currentUser.Username}, ProjectId={projectId}, IsAdmin={isAdmin}, IsReviewOwner={isReviewOwner}, HasDonated={hasDonated}");

                    var allDonations = context.Donations
                        .Where(d => d.UserId == currentUser.Id)
                        .Select(d => new { d.ProjectId, d.Amount, d.Date })
                        .ToList();
                    System.Diagnostics.Debug.WriteLine($"ReviewDeleteButtonVisibilityConverter: All donations for UserId={currentUser.Id}: {string.Join("; ", allDonations.Select(d => $"ProjectId={d.ProjectId}, Amount={d.Amount}, Date={d.Date}"))}");

                    bool isVisible = isAdmin || (isReviewOwner && hasDonated);
                    System.Diagnostics.Debug.WriteLine($"ReviewDeleteButtonVisibilityConverter: Button visibility for ReviewId={review.Id} is {isVisible}");
                    return isVisible ? Visibility.Visible : Visibility.Collapsed;
                }
            }
            System.Diagnostics.Debug.WriteLine($"ReviewDeleteButtonVisibilityConverter: Invalid parameters. Review={value?.GetType().Name}, Parameter={parameter?.GetType().Name}");
            return Visibility.Collapsed;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

    public class MoneyFormatConverter : IMultiValueConverter
    {
        public object Convert(object[] values, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (values.Length == 2 && values[0] is decimal goalAmount && values[1] is decimal collectedAmount)
            {
                return $"Цель: {goalAmount:N2} BYN | Собрано: {collectedAmount:N2} BYN";
            }
            return "Цель: 0.00 BYN | Собрано: 0.00 BYN";
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}