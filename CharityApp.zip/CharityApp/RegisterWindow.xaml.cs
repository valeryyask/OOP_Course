﻿using System.Linq;
using System.Text.RegularExpressions;
using System.Windows;
using CharityApp.models;

namespace CharityApp
{
    public partial class RegisterWindow : Window
    {
        public RegisterWindow()
        {
            InitializeComponent();
        }

        private void Register_Click(object sender, RoutedEventArgs e)
        {
            string username = UsernameBox.Text.Trim();
            string password = PasswordBox.Password.Trim();
            string fullName = FullNameBox.Text.Trim();
            string email = EmailBox.Text.Trim();
            bool isValid = true;

            ResetErrorMessages();

            if (string.IsNullOrEmpty(username) || username.Length < 4 || username.Length > 50 || !Regex.IsMatch(username, @"^[a-zA-Z0-9_]+$"))
            {
                UsernameError.Text = "Логин должен содержать 4-50 символов (буквы, цифры, подчёркивания).";
                UsernameError.Visibility = Visibility.Visible;
                isValid = false;
            }

            if (string.IsNullOrEmpty(password) || password.Length < 4)
            {
                PasswordError.Text = "Пароль должен содержать минимум 4 символа.";
                PasswordError.Visibility = Visibility.Visible;
                isValid = false;
            }

            if (string.IsNullOrEmpty(fullName) || !Regex.IsMatch(fullName, @"^[a-zA-Zа-яА-Я\s]+$"))
            {
                FullNameError.Text = "Полное имя должно содержать только буквы и пробелы.";
                FullNameError.Visibility = Visibility.Visible;
                isValid = false;
            }

            if (string.IsNullOrEmpty(email) || !Regex.IsMatch(email, @"^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$"))
            {
                EmailError.Text = "Введите корректный email (например, example@domain.com).";
                EmailError.Visibility = Visibility.Visible;
                isValid = false;
            }

            if (isValid)
            {
                using (var context = new CharityDbContext())
                {
                    var existingUser = context.Users.FirstOrDefault(u => u.Username.ToLower() == username.ToLower());
                    if (existingUser != null)
                    {
                        ErrorMessageText.Text = "Пользователь с таким логином уже существует.";
                        ErrorMessageText.Visibility = Visibility.Visible;
                        isValid = false;
                    }
                }
            }

            if (!isValid)
            {
                ErrorMessageText.Text = string.IsNullOrEmpty(ErrorMessageText.Text) ? "Исправьте ошибки в полях." : ErrorMessageText.Text;
                ErrorMessageText.Visibility = Visibility.Visible;
                return;
            }

            using (var context = new CharityDbContext())
            {
                var newUser = new User
                {
                    Username = username,
                    Password = password, 
                    FullName = fullName,
                    Email = email,
                    Role = "User",
                    IsBlocked = false
                };

                context.Users.Add(newUser);
                context.SaveChanges();

                MessageBox.Show("Регистрация прошла успешно!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                this.Close();
            }
        }

        private void ResetErrorMessages()
        {
            UsernameError.Text = "";
            UsernameError.Visibility = Visibility.Collapsed;
            PasswordError.Text = "";
            PasswordError.Visibility = Visibility.Collapsed;
            FullNameError.Text = "";
            FullNameError.Visibility = Visibility.Collapsed;
            EmailError.Text = "";
            EmailError.Visibility = Visibility.Collapsed;
            ErrorMessageText.Text = "";
            ErrorMessageText.Visibility = Visibility.Collapsed;
        }
    }
}