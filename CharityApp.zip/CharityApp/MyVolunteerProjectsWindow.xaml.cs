﻿using System.Collections.Generic;
using System.Linq;
using System.Windows;
using CharityApp.models;
using Microsoft.EntityFrameworkCore;

namespace CharityApp
{
    public partial class MyVolunteerProjectsWindow : Window
    {
        private readonly User _currentUser;

        public MyVolunteerProjectsWindow(User currentUser)
        {
            InitializeComponent();
            _currentUser = currentUser;
            LoadVolunteerProjects();
        }

        private void LoadVolunteerProjects()
        {
            using (var context = new CharityDbContext())
            {
                var volunteerProjects = context.Volunteers
                    .Where(v => v.UserId == _currentUser.Id && !v.IsBlocked)
                    .Include(v => v.Project)
                        .ThenInclude(p => p.Category)
                    .Select(v => v.Project)
                    .Where(p => p != null)
                    .Distinct()
                    .ToList();

                VolunteerProjectsListView.ItemsSource = volunteerProjects;
            }
        }
    }
}
