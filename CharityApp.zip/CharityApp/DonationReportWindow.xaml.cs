﻿using System;
using System.Linq;
using System.Windows;
using CharityApp.models;
using Microsoft.EntityFrameworkCore;

namespace CharityApp
{
    public partial class DonationReportWindow : Window
    {
        private class ProjectDonationViewModel
        {
            public string ProjectTitle { get; set; }
            public decimal TotalAmount { get; set; }
        }

        private class RecentDonationViewModel
        {
            public DateTime Date { get; set; }
            public decimal TotalAmount { get; set; }
        }

        public DonationReportWindow()
        {
            InitializeComponent();
            LoadDonationReport();
        }

        private void LoadDonationReport()
        {
            using (var context = new CharityDbContext())
            {
                var totalDonations = context.Donations.Sum(d => d.Amount);
                TotalDonationsText.Text = $"Общая сумма пожертвований: {totalDonations:N2} BYN";
                var projectDonations = context.Donations
                    .Include(d => d.Project)
                    .GroupBy(d => d.Project.Title)
                    .Select(g => new ProjectDonationViewModel
                    {
                        ProjectTitle = g.Key,
                        TotalAmount = g.Sum(d => d.Amount)
                    })
                    .ToList();
                System.Diagnostics.Debug.WriteLine("Project Donations: " + string.Join(", ", projectDonations.Select(p => p.ProjectTitle)));
                ProjectDonationsList.ItemsSource = projectDonations;

                var startDate = DateTime.Today.AddDays(-30).Date;
                var endDate = DateTime.Today.Date.AddDays(1); 
                var recentDonations = context.Donations
                    .Where(d => d.Date >= startDate && d.Date < endDate)
                    .GroupBy(d => d.Date.Date)
                    .Select(g => new RecentDonationViewModel
                    {
                        Date = g.Key,
                        TotalAmount = g.Sum(d => d.Amount)
                    })
                    .OrderBy(g => g.Date)
                    .ToList();
                System.Diagnostics.Debug.WriteLine("Recent Donations: " + string.Join(", ", recentDonations.Select(r => $"{r.Date:dd.MM.yyyy} ({r.TotalAmount:N2} BYN)")));
                RecentDonationsList.ItemsSource = recentDonations;

                NoRecentDonationsText.Visibility = recentDonations.Any() ? Visibility.Collapsed : Visibility.Visible;
            }
        }

        private void Refresh_Click(object sender, RoutedEventArgs e)
        {
            LoadDonationReport();
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}