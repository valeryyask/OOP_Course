﻿using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using CharityApp.models;

namespace CharityApp
{
    public partial class AdminPanelWindow : Window
    {
        private class UserViewModel
        {
            public int Id { get; set; }
            public string Username { get; set; }
            public string Role { get; set; }
            public bool IsBlocked { get; set; }
        }

        private class ProjectViewModel
        {
            public int Id { get; set; }
            public string Title { get; set; }
            public string Category { get; set; }
            public string Status { get; set; }
            public decimal GoalAmount { get; set; }
            public decimal CollectedAmount { get; set; }
        }

        public AdminPanelWindow()
        {
            InitializeComponent();
            LoadUsersAsync();
            LoadProjectsAsync();
        }

        private async Task LoadUsersAsync()
        {
            try
            {
                using (var context = new CharityDbContext())
                {
                    var users = await context.Users
                        .Select(u => new UserViewModel
                        {
                            Id = u.Id,
                            Username = u.Username,
                            Role = u.Role,
                            IsBlocked = u.IsBlocked
                        })
                        .ToListAsync();
                    System.Diagnostics.Debug.WriteLine("Loaded Users: " + string.Join(", ", users.Select(u => u.Username)));
                    UserList.ItemsSource = users;
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error loading users: {ex.Message}");
                MessageBox.Show($"Ошибка загрузки пользователей: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private async Task LoadProjectsAsync()
        {
            try
            {
                using (var context = new CharityDbContext())
                {
                    var projects = await context.Projects
                        .Include(p => p.Category)
                        .Include(p => p.Status)
                        .Select(p => new ProjectViewModel
                        {
                            Id = p.Id,
                            Title = p.Title,
                            Category = p.Category != null ? p.Category.Name : "Не указано",
                            Status = p.Status != null ? p.Status.Name : "Не указано",
                            GoalAmount = p.GoalAmount,
                            CollectedAmount = p.CollectedAmount
                        })
                        .ToListAsync();
                    System.Diagnostics.Debug.WriteLine("Loaded Projects: " + string.Join(", ", projects.Select(p => p.Title)));
                    ProjectList.ItemsSource = projects;
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error loading projects: {ex.Message}");
                MessageBox.Show($"Ошибка загрузки проектов: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void AddUser_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Функция добавления пользователя еще не реализована.");
        }

        private async void BlockUser_Click(object sender, RoutedEventArgs e)
        {
            if (UserList.SelectedItem is UserViewModel selected)
            {
                try
                {
                    using (var context = new CharityDbContext())
                    {
                        var user = await context.Users.FindAsync(selected.Id);
                        if (user != null)
                        {
                            user.IsBlocked = !user.IsBlocked;
                            await context.SaveChangesAsync();
                            MessageBox.Show($"Пользователь {user.Username} {(user.IsBlocked ? "заблокирован" : "разблокирован")}.");
                            await LoadUsersAsync(); 
                        }
                    }
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"Error blocking/unblocking user: {ex.Message}");
                    MessageBox.Show($"Ошибка при изменении статуса пользователя: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("Выберите пользователя для изменения статуса.", "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private async void DeleteUser_Click(object sender, RoutedEventArgs e)
        {
            if (UserList.SelectedItem is UserViewModel selected)
            {
                try
                {
                    using (var context = new CharityDbContext())
                    {
                        var user = await context.Users.FindAsync(selected.Id);
                        if (user != null)
                        {
                            context.Users.Remove(user);
                            await context.SaveChangesAsync();
                            MessageBox.Show($"Пользователь {user.Username} удален.");
                            await LoadUsersAsync(); 
                        }
                    }
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"Error deleting user: {ex.Message}");
                    MessageBox.Show($"Ошибка при удалении пользователя: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("Выберите пользователя для удаления.", "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private async void DeleteProject_Click(object sender, RoutedEventArgs e)
        {
            if (ProjectList.SelectedItem is ProjectViewModel selected)
            {
                try
                {
                    using (var context = new CharityDbContext())
                    {
                        var project = await context.Projects.FindAsync(selected.Id);
                        if (project == null)
                        {
                            MessageBox.Show($"Проект с ID {selected.Id} не найден.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                            return;
                        }

                        var hasDonations = await context.Donations.AnyAsync(d => d.ProjectId == selected.Id);
                        var hasVolunteerApplications = await context.VolunteerApplications.AnyAsync(v => v.ProjectId == selected.Id);

                        if (hasDonations || hasVolunteerApplications)
                        {
                            string reason = hasDonations ? "пожертвования" : "заявки волонтёров";
                            if (hasDonations && hasVolunteerApplications)
                                reason = "пожертвования и заявки волонтёров";
                            MessageBox.Show($"Нельзя удалить проект '{project.Title}', так как он содержит связанные {reason}.",
                                            "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
                            return;
                        }

                        context.Projects.Remove(project);
                        await context.SaveChangesAsync();
                        MessageBox.Show($"Проект '{project.Title}' удалён.", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                        await LoadProjectsAsync(); 
                    }
                }
                catch (DbUpdateException ex)
                {
                    System.Diagnostics.Debug.WriteLine($"DbUpdateException deleting project: {ex.InnerException?.Message ?? ex.Message}");
                    MessageBox.Show("Ошибка при удалении проекта: проект связан с другими данными (например, пожертвованиями или заявками).",
                                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"Error deleting project: {ex.Message}");
                    MessageBox.Show($"Ошибка при удалении проекта: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("Выберите проект для удаления.", "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void ViewDonationReport_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var donationReportWindow = new DonationReportWindow();
                donationReportWindow.ShowDialog();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error opening donation report window: {ex.Message}");
                MessageBox.Show($"Ошибка при открытии окна отчета: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ManageVolunteers_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var volunteerApplicationsWindow = new VolunteerApplicationsWindow();
                volunteerApplicationsWindow.ShowDialog();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error opening volunteer applications window: {ex.Message}");
                MessageBox.Show($"Ошибка при открытии окна заявок волонтеров: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}