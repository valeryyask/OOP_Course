﻿using System;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using CharityApp.models;
using Microsoft.EntityFrameworkCore;

namespace CharityApp
{
    public partial class LoginWindow : Window
    {
        public User LoggedInUser { get; private set; }

        public LoginWindow()
        {
            InitializeComponent();
            this.WindowStartupLocation = WindowStartupLocation.CenterScreen;
        }

        private async void Login_Click(object sender, RoutedEventArgs e)
        {
            string login = UsernameBox.Text.Trim();
            string password = PasswordBox.Password.Trim();

            if (string.IsNullOrWhiteSpace(login) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Введите логин и пароль", "Ошибка",
                                MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                using (var context = new CharityDbContext())
                {
                    var user = await context.Users
                        .FirstOrDefaultAsync(u => u.Username == login);

                    if (user == null)
                    {
                        MessageBox.Show("Неверный логин или пароль", "Ошибка входа",
                                        MessageBoxButton.OK, MessageBoxImage.Error);
                        PasswordBox.Clear();
                        UsernameBox.Focus();
                        return;
                    }

                    if (user.IsBlocked)
                    {
                        MessageBox.Show("Ваш аккаунт заблокирован. Обратитесь к администратору.", "Доступ запрещен",
                                        MessageBoxButton.OK, MessageBoxImage.Error);
                        PasswordBox.Clear();
                        UsernameBox.Focus();
                        return;
                    }

                    if (user.Password == password)
                    {
                        LoggedInUser = user;
                        var mainWindow = new MainWindow(user);
                        mainWindow.Show();
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Неверный логин или пароль", "Ошибка входа",
                                        MessageBoxButton.OK, MessageBoxImage.Error);
                        PasswordBox.Clear();
                        UsernameBox.Focus();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Произошла ошибка при входе: {ex.Message}", "Ошибка",
                                MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Register_Click(object sender, RoutedEventArgs e)
        {
            var registerWindow = new RegisterWindow();
            registerWindow.ShowDialog();

            if (registerWindow.DialogResult == true)
            {
                UsernameBox.Clear();
                PasswordBox.Clear();
                UsernameBox.Focus();
            }
        }
    }
}