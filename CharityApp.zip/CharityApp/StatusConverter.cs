﻿using System;
using System.Windows.Data;

namespace CharityApp
{
    public class StatusConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            string status = value as string;
            return status switch
            {
                "Active" => "Активен",
                "Completed" => "Завершен",
                "Canceled" => "Отменен",
                _ => "Неизвестно"
            };
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}