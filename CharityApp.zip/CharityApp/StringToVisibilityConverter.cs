﻿using System;
using System.Windows;
using System.Windows.Data;

namespace CharityApp
{
    public class StringToVisibilityConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            string text = value as string;
            string expected = parameter as string;

            if (expected != null && expected.StartsWith("Invalid", StringComparison.OrdinalIgnoreCase))
            {
                return string.IsNullOrEmpty(text) ? Visibility.Collapsed : Visibility.Visible;
            }

            return string.IsNullOrEmpty(text) || (expected != null && text != expected)
                ? Visibility.Collapsed
                : Visibility.Visible;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}