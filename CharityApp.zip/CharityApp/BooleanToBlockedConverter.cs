﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace CharityApp
{
    public class BooleanToBlockedConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (value is not bool isBlocked)
            {
                return DependencyProperty.UnsetValue; 
            }

            if (parameter == null)
            {
                return isBlocked ? "Заблокирован" : "Активен"; 
            }

            string param = parameter.ToString();
            switch (param)
            {
                case "ButtonText":
                    return isBlocked ? "Разблокировать" : "Заблокировать";

                case "ButtonStyle":
                    Style primaryStyle = Application.Current.TryFindResource("PrimaryButtonStyle") as Style;
                    Style dangerStyle = Application.Current.TryFindResource("DangerButtonStyle") as Style;
                    return isBlocked ? primaryStyle ?? new Style(typeof(Button)) : dangerStyle ?? new Style(typeof(Button));

                case "UIElement":
                    var button = new Button
                    {
                        Content = isBlocked ? "Разблокировать" : "Заблокировать",
                        Style = isBlocked ? (Application.Current.TryFindResource("PrimaryButtonStyle") as Style ?? new Style(typeof(Button)))
                                         : (Application.Current.TryFindResource("DangerButtonStyle") as Style ?? new Style(typeof(Button))),
                        Padding = new Thickness(5),
                        Margin = new Thickness(2)
                    };
                    return button;

                default:
                    return isBlocked ? "Заблокирован" : "Активен";
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}