﻿using System;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Windows.Data;

namespace CharityApp
{
    public class CardNumberFormatter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value == null || string.IsNullOrWhiteSpace(value.ToString()))
                return string.Empty;

            var input = Regex.Replace(value.ToString(), @"\D", "");
            if (input.Length > 16)
                input = input.Substring(0, 16);

            var formatted = "";
            for (int i = 0; i < input.Length; i++)
            {
                if (i > 0 && i % 4 == 0)
                    formatted += " ";
                formatted += input[i];
            }
            return formatted;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value == null)
                return string.Empty;
            return Regex.Replace(value.ToString(), @"\s", "");
        }
    }
}