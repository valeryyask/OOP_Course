﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using CharityApp.models;
using Microsoft.EntityFrameworkCore;

namespace CharityApp
{
    public partial class MainWindow : Window
    {
        private User _currentUser;
        public static List<Project> AllProjectsGlobal { get; set; } = new List<Project>();

        public MainWindow() : this(new User { Username = "Гость", Role = "User" }) { }

        public MainWindow(User currentUser)
        {
            InitializeComponent();
            _currentUser = currentUser ?? throw new ArgumentNullException(nameof(currentUser));
            DataContext = this;
            LoadProjectsFromDatabase();
            RefreshProjectList();
            ApplyRolePermissions();
        }

        private void ApplyRolePermissions()
        {
            if (_currentUser.Role != "Admin")
            {
                AddProjectButton.Visibility = Visibility.Collapsed;
                if (MenuAddProject != null)
                    MenuAddProject.Visibility = Visibility.Collapsed;
                if (AdminPanelMenu != null)
                    AdminPanelMenu.Visibility = Visibility.Collapsed;
            }
        }

        public List<Project> AllProjects { get; set; } = new List<Project>();
        public List<ProjectViewModel> FilteredProjects { get; set; } = new List<ProjectViewModel>();

        private void LoadProjectsFromDatabase()
        {
            try
            {
                using (var context = new CharityDbContext())
                {
                    AllProjectsGlobal = context.Projects
                                               .Include(p => p.Category)
                                               .Include(p => p.Status)
                                               .ToList();
                }
                AllProjects = AllProjectsGlobal;
                System.Diagnostics.Debug.WriteLine($"Загружено {AllProjectsGlobal.Count} проектов из базы данных.");
                foreach (var project in AllProjectsGlobal)
                {
                    System.Diagnostics.Debug.WriteLine($"Проект: Id={project.Id}, Title={project.Title}, CategoryId={project.CategoryId}, CategoryName={project.Category?.Name ?? "null"}");
                }
                var invalidProjects = AllProjectsGlobal.Where(p => p.Category == null).ToList();
                if (invalidProjects.Any())
                {
                    System.Diagnostics.Debug.WriteLine($"Найдено {invalidProjects.Count} проектов с некорректными CategoryId:");
                    foreach (var p in invalidProjects)
                    {
                        System.Diagnostics.Debug.WriteLine($"Проект Id={p.Id}, Title={p.Title}, CategoryId={p.CategoryId}");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке проектов: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                System.Diagnostics.Debug.WriteLine($"Ошибка загрузки проектов: {ex}");
            }
        }

        private void RefreshProjectList()
        {
            try
            {
                string search = SearchBox.Text?.ToLower().Trim() ?? "";

                decimal min = 0;
                decimal max = decimal.MaxValue;
                if (!string.IsNullOrWhiteSpace(MinAmountBox.Text) && !decimal.TryParse(MinAmountBox.Text, out min))
                {
                    MessageBox.Show("Минимальная сумма введена некорректно. Используется 0.", "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
                    MinAmountBox.Text = "";
                    min = 0;
                }
                if (!string.IsNullOrWhiteSpace(MaxAmountBox.Text) && !decimal.TryParse(MaxAmountBox.Text, out max))
                {
                    MessageBox.Show("Максимальная сумма введена некорректно. Используется максимальное значение.", "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
                    MaxAmountBox.Text = "";
                    max = decimal.MaxValue;
                }

                System.Diagnostics.Debug.WriteLine($"Применение фильтров: Поиск='{search}', Мин. сумма={min}, Макс. сумма={max}");

                var filteredProjects = AllProjectsGlobal
                    .Where(p =>
                        (string.IsNullOrWhiteSpace(search) || (p.Title?.ToLower().Contains(search) ?? false)) &&
                        p.GoalAmount >= min &&
                        p.GoalAmount <= max
                    )
                    .ToList();

                AllProjects = filteredProjects;
                FilteredProjects = filteredProjects
                    .Select(p => new ProjectViewModel
                    {
                        Project = p
                    })
                    .ToList();

                ProjectsListView.ItemsSource = null;
                ProjectsListView.ItemsSource = FilteredProjects;
                System.Diagnostics.Debug.WriteLine($"Отфильтровано {FilteredProjects.Count} проектов: {string.Join(", ", FilteredProjects.Select(p => p.Title ?? "Без названия"))}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при фильтрации проектов: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                System.Diagnostics.Debug.WriteLine($"Ошибка фильтрации: {ex}");
            }
        }

        private void ApplyFilters_Click(object sender, RoutedEventArgs e)
        {
            System.Diagnostics.Debug.WriteLine("Нажата кнопка 'Применить фильтры'");
            RefreshProjectList();
        }

        private void SearchBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            System.Diagnostics.Debug.WriteLine($"Текст поиска изменён: {SearchBox.Text}");
            RefreshProjectList();
        }

        private void AmountBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            System.Diagnostics.Debug.WriteLine($"Изменены суммы: Мин={MinAmountBox.Text}, Макс={MaxAmountBox.Text}");
            RefreshProjectList();
        }

        private void ProjectsListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ProjectsListView.SelectedItem is ProjectViewModel selectedProjectViewModel)
            {
                var detailsWindow = new ProjectDetailsWindow(selectedProjectViewModel.Project, _currentUser);
                detailsWindow.ShowDialog();
                ProjectsListView.SelectedItem = null;
                LoadProjectsFromDatabase(); 
                RefreshProjectList();
            }
        }

        private void AddProject_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var window = new AddProjectWindow();
                if (window.ShowDialog() == true)
                {
                    LoadProjectsFromDatabase();
                    ResetFilters();
                    RefreshProjectList();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении проекта: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                System.Diagnostics.Debug.WriteLine($"Ошибка добавления проекта: {ex}");
            }
        }

        private void HomeMenu_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Главная страница (список проектов)");
        }

        private void ApplyVolunteerMenu_Click(object sender, RoutedEventArgs e)
        {
            var applyWindow = new ApplyVolunteerWindow(_currentUser);
            applyWindow.ShowDialog();
            RefreshProjectList();
        }

        private void MyVolunteerProjectsMenu_Click(object sender, RoutedEventArgs e)
        {
            var window = new MyVolunteerProjectsWindow(_currentUser);
            window.ShowDialog();
            RefreshProjectList();
        }

        private void AddProjectMenu_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var window = new AddProjectWindow();
                if (window.ShowDialog() == true)
                {
                    LoadProjectsFromDatabase();
                    ResetFilters();
                    RefreshProjectList();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении проекта: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                System.Diagnostics.Debug.WriteLine($"Ошибка добавления проекта (меню): {ex}");
            }
        }

        private void ProfileMenu_Click(object sender, RoutedEventArgs e)
        {
            var profileWindow = new ProfileWindow(_currentUser);
            profileWindow.ShowDialog();
        }

        private void LogoutMenu_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void DonationsMenu_Click(object sender, RoutedEventArgs e)
        {
            var window = new MyDonationsWindow(_currentUser);
            window.ShowDialog();
        }

        private void AdminPanelMenu_Click(object sender, RoutedEventArgs e)
        {
            var adminWindow = new AdminPanelWindow();
            adminWindow.ShowDialog();
        }

        private void ToggleTheme_Click(object sender, RoutedEventArgs e)
        {
            ThemeManager.ToggleTheme();
        }

        private void ResetFilters()
        {
            SearchBox.Text = "";
            MinAmountBox.Text = "";
            MaxAmountBox.Text = "";
            System.Diagnostics.Debug.WriteLine("Фильтры сброшены");
        }
    }

    public class ProjectViewModel
    {
        public Project Project { get; set; }

        public string Title => Project.Title;
        public string Category => Project.Category?.Name ?? "Не указана";
        public string Status => Project.Status?.Name ?? "Не указан";
        public decimal TargetAmount => Project.GoalAmount;
        public decimal CollectedAmount => Project.CollectedAmount;
        public string ImagePath => Project.ImagePath;
    }

    public class RelayCommand : ICommand
    {
        private readonly Action<object> _execute;
        private readonly Func<object, bool> _canExecute;

        public event EventHandler CanExecuteChanged
        {
            add { CommandManager.RequerySuggested += value; }
            remove { CommandManager.RequerySuggested -= value; }
        }

        public RelayCommand(Action<object> execute, Func<object, bool> canExecute = null)
        {
            _execute = execute ?? throw new ArgumentNullException(nameof(execute));
            _canExecute = canExecute;
        }

        public bool CanExecute(object parameter) => _canExecute == null || _canExecute(parameter);

        public void Execute(object parameter) => _execute(parameter);
    }
}