﻿using System.Windows;

namespace CharityApp
{
    //public partial class App : Application
    //{
    //    protected override void OnStartup(StartupEventArgs e)
    //    {
    //        base.OnStartup(e);

    //        var loginWindow = new LoginWindow();
    //        if (loginWindow.ShowDialog() == true)
    //        {
    //            var mainWindow = new MainWindow(loginWindow.LoggedInUser);
    //            mainWindow.Show();
    //        }
    //        else
    //        {
    //            Current.Shutdown();
    //        }
    //    }
    //}
}