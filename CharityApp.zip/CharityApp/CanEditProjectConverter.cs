﻿using CharityApp.models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Windows;
using System.Windows.Data;

namespace CharityApp
{
    public class CanEditProjectConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (value is Project project && parameter is User user)
            {
                if (user.Role == "Admin")
                {
                    return Visibility.Visible;
                }

                using (var context = new CharityDbContext())
                {
                    bool isVolunteer = context.Volunteers
                        .Any(v => v.UserId == user.Id && v.ProjectId == project.Id && !v.IsBlocked);
                    return isVolunteer ? Visibility.Visible : Visibility.Collapsed;
                }
            }
            return Visibility.Collapsed;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}