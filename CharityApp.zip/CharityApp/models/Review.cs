﻿using System;
using System.ComponentModel.DataAnnotations;

namespace CharityApp.models
{
    public class Review
    {
        public int Id { get; set; }

        [Required]
        public string Content { get; set; }

        [Required]
        public int UserId { get; set; }
        public User User { get; set; }

        [Required]
        public int ProjectId { get; set; }
        public Project Project { get; set; }

        [Required]
        public DateTime CreatedAt { get; set; }
    }
}