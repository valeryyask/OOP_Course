﻿using System;

namespace CharityApp.models
{
    public class Volunteer
    {
        public int Id { get; set; }

        public int UserId { get; set; }
        public int ProjectId { get; set; }
        public bool IsBlocked { get; set; }

        // Новые поля
        public DateTime DateJoined { get; set; } // Дата вступления в проект
        public string RoleInProject { get; set; } // Роль в проекте

        public User User { get; set; }
        public Project Project { get; set; }
    }
}
