﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace CharityApp.models
{
    public class Project
    {
        public int Id { get; set; }

        [Required]
        public string Title { get; set; }

        public string FullTitle { get; set; }

        public string Description { get; set; }

        [Required]
        public int CategoryId { get; set; }
        public Category Category { get; set; }

        [Required]
        public decimal GoalAmount { get; set; }

        public decimal CollectedAmount { get; set; }

        [Required]
        public int StatusId { get; set; }
        public Status Status { get; set; }

        public DateTime EndDate { get; set; }

        [Required]
        public string ImagePath { get; set; }

        public ICollection<Donation> Donations { get; set; }
        public ICollection<Review> Reviews { get; set; } // Новая коллекция отзывов
    }
}