﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static CharityApp.MyDonationsWindow;

namespace CharityApp.models
{
    public class User
    {
        public int Id { get; set; }

        [Required]
        public string Username { get; set; }

        [Required]
        public string Password { get; set; }

        public string Role { get; set; } = "User";

        public string FullName { get; set; }

        public string Email { get; set; }

        public ICollection<Donation> Donations { get; set; }
        public bool IsBlocked { get; set; }
    }
}