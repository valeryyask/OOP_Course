﻿using System;
using System.Windows;

namespace CharityApp
{
    public static class ThemeManager
    {
        public static string CurrentTheme { get; private set; } = "Light";

        public static void SwitchTheme(string theme)
        {
            if (theme == CurrentTheme) return;

            string fileName = theme == "Light" ? "Style.xaml" : "DarkTheme.xaml";

            var newTheme = new ResourceDictionary
            {
                Source = new Uri($"/resource/{fileName}", UriKind.Relative)
            };

            Application.Current.Resources.MergedDictionaries.Clear();
            Application.Current.Resources.MergedDictionaries.Add(newTheme);

            CurrentTheme = theme;
        }

        public static void ToggleTheme()
        {
            SwitchTheme(CurrentTheme == "Light" ? "Dark" : "Light");
        }
    }
}
