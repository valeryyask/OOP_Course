﻿using CharityApp.models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Win32;
using System;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace CharityApp
{
    public partial class AddProjectWindow : Window
    {
        private readonly Project _projectToEdit;
        private readonly bool _isEditMode;
        public string ImagePath { get; set; }

        public AddProjectWindow() : this(null)
        {
        }

        public AddProjectWindow(Project project)
        {
            InitializeComponent();
            _projectToEdit = project;
            _isEditMode = project != null;
            LoadCategories();
            if (_isEditMode)
            {
                PopulateFields();
                Title = "Редактировать проект";
            }
            else
            {
                Title = "Добавить проект";
                EndDatePicker.SelectedDate = DateTime.Today.AddMonths(1);
            }
        }

        private void LoadCategories()
        {
            try
            {
                using (var context = new CharityDbContext())
                {
                    var categories = context.Categories.ToList();
                    CategoryComboBox.Items.Clear();
                    if (categories == null || !categories.Any())
                    {
                        MessageBox.Show("В базе данных отсутствуют категории. Добавьте хотя бы одну категорию перед созданием проекта.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                        CategoryComboBox.Items.Add(new Category { Id = 0, Name = "Нет категорий" });
                        CategoryComboBox.IsEnabled = false;
                    }
                    else
                    {
                        CategoryComboBox.ItemsSource = categories;
                        CategoryComboBox.DisplayMemberPath = "Name";
                        CategoryComboBox.SelectedValuePath = "Id";
                    }
                    System.Diagnostics.Debug.WriteLine($"Loaded {categories.Count} categories for ComboBox.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке категорий: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                System.Diagnostics.Debug.WriteLine($"Category load error: {ex.Message}");
                CategoryComboBox.Items.Clear();
                CategoryComboBox.Items.Add(new Category { Id = 0, Name = "Ошибка загрузки" });
                CategoryComboBox.IsEnabled = false;
            }
        }

        private void PopulateFields()
        {
            TitleBox.Text = _projectToEdit.Title;
            FullTitleBox.Text = _projectToEdit.FullTitle;
            DescriptionBox.Text = _projectToEdit.Description;
            TargetAmountBox.Text = _projectToEdit.GoalAmount.ToString(CultureInfo.InvariantCulture);
            EndDatePicker.SelectedDate = _projectToEdit.EndDate;
            CategoryComboBox.SelectedValue = _projectToEdit.CategoryId;
            ImagePath = _projectToEdit.ImagePath;
        }

        private void UploadImage_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog
            {
                Title = "Выберите изображение проекта",
                Filter = "Изображения (*.png;*.jpg;*.jpeg)|*.png;*.jpg;*.jpeg"
            };

            if (dialog.ShowDialog() == true)
            {
                ImagePath = dialog.FileName;
                MessageBox.Show("Изображение выбрано:\n" + ImagePath, "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                System.Diagnostics.Debug.WriteLine($"Selected image: {ImagePath}");
            }
        }

        private void RestrictNumberInput(object sender, TextCompositionEventArgs e)
        {
            TextBox textBox = sender as TextBox;
            string newText = textBox.Text + e.Text;

            if (!char.IsDigit(e.Text, 0) && e.Text != ".")
            {
                e.Handled = true;
                return;
            }

            if (e.Text == "." && textBox.Text.Contains("."))
            {
                e.Handled = true;
                return;
            }

            if (textBox.Text.Contains("."))
            {
                int decimalPointIndex = textBox.Text.IndexOf(".");
                string afterDecimal = textBox.Text.Substring(decimalPointIndex + 1);
                if (afterDecimal.Length >= 2 && char.IsDigit(e.Text, 0))
                {
                    e.Handled = true;
                    return;
                }
            }

            if (decimal.TryParse(newText.Replace(",", "."), out decimal amount) && amount > 1000000000)
            {
                e.Handled = true;
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(TitleBox.Text) ||
                string.IsNullOrWhiteSpace(FullTitleBox.Text) ||
                string.IsNullOrWhiteSpace(TargetAmountBox.Text))
            {
                MessageBox.Show("Пожалуйста, заполните обязательные поля: название, полное название, целевая сумма.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (TitleBox.Text.Length > 100)
            {
                MessageBox.Show("Название проекта не должно превышать 100 символов.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (FullTitleBox.Text.Length > 200)
            {
                MessageBox.Show("Полное название проекта не должно превышать 200 символов.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (DescriptionBox.Text.Length > 1000)
            {
                MessageBox.Show("Описание проекта не должно превышать 1000 символов.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var selectedCategory = CategoryComboBox.SelectedItem as Category;
            if (selectedCategory == null || selectedCategory.Id == 0)
            {
                MessageBox.Show("Пожалуйста, выберите действительную категорию или добавьте категорию в базе данных.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (string.IsNullOrEmpty(ImagePath))
            {
                MessageBox.Show("Пожалуйста, загрузите изображение проекта.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (!decimal.TryParse(TargetAmountBox.Text, NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture, out decimal goalAmount) || goalAmount <= 0)
            {
                MessageBox.Show("Целевая сумма должна быть положительным числом.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (!EndDatePicker.SelectedDate.HasValue)
            {
                MessageBox.Show("Пожалуйста, выберите дату окончания проекта.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                using (var context = new CharityDbContext())
                {
                    var status = context.Statuses.FirstOrDefault(s => s.Name.ToLower() == "активен");
                    if (status == null)
                    {
                        MessageBox.Show("Статус 'Активен' не найден в базе данных. Убедитесь, что таблица Statuses содержит соответствующий статус.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                        System.Diagnostics.Debug.WriteLine("Status 'Активен' not found in database.");
                        return;
                    }

                    var categoryInDb = context.Categories.Find(selectedCategory.Id);
                    if (categoryInDb == null)
                    {
                        MessageBox.Show("Выбранная категория не найдена в базе данных. Пожалуйста, выберите другую категорию.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }

                    Project project;
                    if (_isEditMode)
                    {
                        project = context.Projects.FirstOrDefault(p => p.Id == _projectToEdit.Id);
                        if (project == null)
                        {
                            MessageBox.Show("Проект не найден в базе данных.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                            return;
                        }
                    }
                    else
                    {
                        project = new Project();
                    }

                    project.Title = TitleBox.Text.Trim();
                    project.FullTitle = FullTitleBox.Text.Trim();
                    project.Description = DescriptionBox.Text.Trim();
                    project.GoalAmount = goalAmount;
                    project.CollectedAmount = _isEditMode ? project.CollectedAmount : 0;
                    project.Status = status;
                    project.Category = categoryInDb;
                    project.EndDate = EndDatePicker.SelectedDate.Value;
                    project.ImagePath = ImagePath;

                    if (!_isEditMode)
                    {
                        context.Projects.Add(project);
                    }

                    context.SaveChanges();

                    MessageBox.Show(_isEditMode ? "Проект успешно обновлен!" : "Проект успешно добавлен!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                    DialogResult = true;
                    Close();
                }
            }
            catch (Exception ex)
            {
                string errorMessage = $"Произошла ошибка при {(_isEditMode ? "обновлении" : "добавлении")} проекта: {ex.Message}";
                if (ex.InnerException != null)
                {
                    errorMessage += $"\nПодробности: {ex.InnerException.Message}";
                }
                MessageBox.Show(errorMessage, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                System.Diagnostics.Debug.WriteLine($"Save error: {ex.Message}, Inner: {ex.InnerException?.Message}");
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}