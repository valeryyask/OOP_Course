﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;
using CharityApp.models;

namespace CharityApp
{
    public partial class ApplyVolunteerWindow : Window
    {
        private readonly User _currentUser;

        public ApplyVolunteerWindow(User currentUser)
        {
            InitializeComponent();
            _currentUser = currentUser;
            LoadProjectsAsync();
        }

        private async Task LoadProjectsAsync()
        {
            try
            {
                using (var context = new CharityDbContext())
                {
                    var projects = await context.Projects
                        .Include(p => p.Category)
                        .ToListAsync();
                    System.Diagnostics.Debug.WriteLine("Projects: " + string.Join(", ", projects.Select(p => p.Title)));
                    ProjectComboBox.ItemsSource = projects;

                    NoProjectsText.Visibility = projects.Any() ? Visibility.Collapsed : Visibility.Visible;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Произошла ошибка при загрузке проектов: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                NoProjectsText.Visibility = Visibility.Visible;
            }
        }

        private async void SubmitApplication_Click(object sender, RoutedEventArgs e)
        {
            if (ProjectComboBox.SelectedItem is Project selectedProject && !string.IsNullOrWhiteSpace(MotivationTextBox.Text))
            {
                try
                {
                    using (var context = new CharityDbContext())
                    {
                        var existingApplication = await context.VolunteerApplications
                            .FirstOrDefaultAsync(a => a.UserId == _currentUser.Id && a.ProjectId == selectedProject.Id);
                        if (existingApplication != null)
                        {
                            MessageBox.Show("Вы уже подали заявку на этот проект!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                            return;
                        }

                        var application = new VolunteerApplication
                        {
                            UserId = _currentUser.Id,
                            ProjectId = selectedProject.Id,
                            Motivation = MotivationTextBox.Text,
                            Status = "Pending",
                            Notes = string.Empty 
                        };
                        System.Diagnostics.Debug.WriteLine($"New Application: UserId={application.UserId}, ProjectId={application.ProjectId}, Motivation={application.Motivation}, Status={application.Status}, Notes={application.Notes}");

                        context.VolunteerApplications.Add(application);
                        await context.SaveChangesAsync();

                        MessageBox.Show("Заявка успешно отправлена! Ожидайте рассмотрения.", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                        Close();
                    }
                }
                catch (DbUpdateException ex)
                {
                    string innerMessage = ex.InnerException != null ? ex.InnerException.Message : "Нет дополнительной информации.";
                    MessageBox.Show($"Ошибка при сохранении заявки: {ex.Message}. Подробности: {innerMessage}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    System.Diagnostics.Debug.WriteLine($"DbUpdateException: {ex.Message}, Inner: {innerMessage}");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Произошла ошибка при отправке заявки: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    System.Diagnostics.Debug.WriteLine($"Exception: {ex.Message}");
                }
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите проект и укажите мотивацию.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }

    public class CollectionNotEmptyConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (value is System.Collections.ICollection collection)
            {
                return collection.Count > 0;
            }
            return false;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}