﻿using System.Windows;
using CharityApp.models;
using Microsoft.EntityFrameworkCore;

namespace CharityApp
{
    public partial class ProfileWindow : Window
    {
        private User _currentUser;

        public ProfileWindow(User currentUser)
        {
            InitializeComponent();
            _currentUser = currentUser;

            UsernameText.Text = _currentUser.Username;
            FullNameBox.Text = _currentUser.FullName;
            EmailBox.Text = _currentUser.Email;
        }

        private void SaveChanges_Click(object sender, RoutedEventArgs e)
        {
            using (var context = new CharityDbContext())
            {
                var userInDb = context.Users.FirstOrDefault(u => u.Id == _currentUser.Id);
                if (userInDb == null)
                {
                    MessageBox.Show("Пользователь не найден в базе данных.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                userInDb.FullName = FullNameBox.Text.Trim();
                userInDb.Email = EmailBox.Text.Trim();

                if (!string.IsNullOrEmpty(CurrentPasswordBox.Password) ||
                    !string.IsNullOrEmpty(NewPasswordBox.Password) ||
                    !string.IsNullOrEmpty(ConfirmNewPasswordBox.Password))
                {
                    if (userInDb.Password != CurrentPasswordBox.Password)
                    {
                        MessageBox.Show("Текущий пароль введен неверно.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }

                    if (NewPasswordBox.Password != ConfirmNewPasswordBox.Password)
                    {
                        MessageBox.Show("Новый пароль и подтверждение не совпадают.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }

                    userInDb.Password = NewPasswordBox.Password;
                    MessageBox.Show("Пароль успешно изменен!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                }

                context.SaveChanges();

                _currentUser.FullName = userInDb.FullName;
                _currentUser.Email = userInDb.Email;
                _currentUser.Password = userInDb.Password;

                MessageBox.Show("Изменения успешно сохранены!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
