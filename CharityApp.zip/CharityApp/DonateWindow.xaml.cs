﻿using System;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using CharityApp.models;
using Microsoft.EntityFrameworkCore;

namespace CharityApp
{
    public class CardDetails
    {
        public string CardNumber { get; set; }
        public string CardHolder { get; set; }
        public string ExpiryDate { get; set; }
        public string Cvv { get; set; }
    }

    public partial class DonateWindow : Window
    {
        public decimal Amount { get; private set; }
        public CardDetails CardDetails { get; private set; }
        private readonly User _currentUser;
        private const decimal DAILY_DONATION_LIMIT = 7520m;

        public DonateWindow(User currentUser)
        {
            InitializeComponent();
            CardDetails = new CardDetails();
            _currentUser = currentUser ?? throw new ArgumentNullException(nameof(currentUser));
        }

        private void AmountBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            TextBox textBox = sender as TextBox;
            string newText = textBox.Text + e.Text;

            if (!char.IsDigit(e.Text, 0) && e.Text != "." && e.Text != ",")
            {
                e.Handled = true;
                return;
            }

            if ((e.Text == "." || e.Text == ",") && (textBox.Text.Contains(".") || textBox.Text.Contains(",")))
            {
                e.Handled = true;
                return;
            }

            if (decimal.TryParse(newText.Replace(",", "."), out decimal amount) && amount > DAILY_DONATION_LIMIT)
            {
                e.Handled = true;
            }
        }

        private void CardNumberBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            TextBox textBox = sender as TextBox;
            if (!char.IsDigit(e.Text, 0))
            {
                e.Handled = true;
                return;
            }

            string currentText = Regex.Replace(textBox.Text, @"\D", "");
            if (currentText.Length >= 16)
            {
                e.Handled = true;
            }
        }

        private void CardNumberBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            TextBox textBox = sender as TextBox;
            if (textBox == null) return;

            textBox.TextChanged -= CardNumberBox_TextChanged;

            string digits = Regex.Replace(textBox.Text, @"\D", "");
            if (digits.Length > 16)
            {
                digits = digits.Substring(0, 16);
            }

            StringBuilder formattedText = new StringBuilder();
            for (int i = 0; i < digits.Length; i++)
            {
                if (i > 0 && i % 4 == 0)
                {
                    formattedText.Append(" ");
                }
                formattedText.Append(digits[i]);
            }

            int caretIndex = textBox.CaretIndex;
            int digitsBeforeCaret = Regex.Replace(textBox.Text.Substring(0, caretIndex), @"\D", "").Length;
            string oldText = textBox.Text;

            textBox.Text = formattedText.ToString();

            int newCaretIndex = 0;
            int currentDigits = 0;
            for (int i = 0; i < formattedText.Length && currentDigits < digitsBeforeCaret; i++)
            {
                if (char.IsDigit(formattedText[i]))
                {
                    currentDigits++;
                }
                newCaretIndex = i + 1;
            }

            if (newCaretIndex > 0 && newCaretIndex < formattedText.Length && formattedText[newCaretIndex - 1] == ' ')
            {
                newCaretIndex++;
            }

            textBox.CaretIndex = Math.Min(newCaretIndex, formattedText.Length);

            textBox.TextChanged += CardNumberBox_TextChanged;
        }

        private void CardHolderBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (!Regex.IsMatch(e.Text, @"[a-zA-Z\s]"))
            {
                e.Handled = true;
            }
        }

        private void ExpiryDateBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (!char.IsDigit(e.Text, 0))
            {
                e.Handled = true;
            }
        }

        private void CvvBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (!char.IsDigit(e.Text, 0))
            {
                e.Handled = true;
            }
        }

        private void CardHolderBox_GotFocus(object sender, RoutedEventArgs e)
        {
            CardHolderBox.SelectAll();
        }

        private void Donate_Click(object sender, RoutedEventArgs e)
        {
            if (!decimal.TryParse(AmountBox.Text, out decimal amount) || amount <= 0)
            {
                AmountErrorTextBlock.Text = "Введите корректную сумму больше 0.";
                AmountErrorTextBlock.Visibility = Visibility.Visible;
                return;
            }

            try
            {
                using (var context = new CharityDbContext())
                {
                    var startDate = DateTime.Today;
                    var endDate = startDate.AddDays(1);
                    var dailyDonations = context.Donations
                        .Where(d => d.UserId == _currentUser.Id && d.Date >= startDate && d.Date < endDate)
                        .Sum(d => d.Amount);

                    if (dailyDonations + amount > DAILY_DONATION_LIMIT)
                    {
                        AmountErrorTextBlock.Text = $"Сумма превышает дневной лимит 7520 BYN. Сегодня вы уже пожертвовали {dailyDonations:N2} BYN.";
                        AmountErrorTextBlock.Visibility = Visibility.Visible;
                        return;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при проверке лимита: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            AmountErrorTextBlock.Visibility = Visibility.Collapsed;

            string cardNumber = CardNumberBox.Text.Replace(" ", "");
            if (!Regex.IsMatch(cardNumber, @"^\d{16}$"))
            {
                CardNumberErrorTextBlock.Text = "Номер карты должен содержать ровно 16 цифр.";
                CardNumberErrorTextBlock.Visibility = Visibility.Visible;
                return;
            }
            CardNumberErrorTextBlock.Visibility = Visibility.Collapsed;

            string cardHolder = CardHolderBox.Text.Trim();
            if (cardHolder.Length < 2 || !Regex.IsMatch(cardHolder, @"^[a-zA-Z\s]+$"))
            {
                CardHolderErrorTextBlock.Text = "Введите корректное имя держателя (латинские буквы, минимум 2 символа).";
                CardHolderErrorTextBlock.Visibility = Visibility.Visible;
                return;
            }
            CardHolderErrorTextBlock.Visibility = Visibility.Collapsed;

            string expiryDate = ExpiryDateBox.Text;
            if (!Regex.IsMatch(expiryDate, @"^(0[1-9]|1[0-2])\d{2}$"))
            {
                ExpiryDateErrorTextBlock.Text = "Введите срок действия в формате MMYY (например, 1225).";
                ExpiryDateErrorTextBlock.Visibility = Visibility.Visible;
                return;
            }
            string formattedExpiry = expiryDate.Insert(2, "/");
            if (!IsValidExpiryDate(formattedExpiry))
            {
                ExpiryDateErrorTextBlock.Text = "Срок действия карты истек или неверный.";
                ExpiryDateErrorTextBlock.Visibility = Visibility.Visible;
                return;
            }
            ExpiryDateErrorTextBlock.Visibility = Visibility.Collapsed;

            string cvv = CvvBox.Text;
            if (!Regex.IsMatch(cvv, @"^\d{3,4}$"))
            {
                CvvErrorTextBlock.Text = "CVV должен содержать 3 или 4 цифры.";
                CvvErrorTextBlock.Visibility = Visibility.Visible;
                return;
            }
            CvvErrorTextBlock.Visibility = Visibility.Collapsed;

            Amount = amount;
            CardDetails.CardNumber = cardNumber;
            CardDetails.CardHolder = cardHolder;
            CardDetails.ExpiryDate = formattedExpiry;
            CardDetails.Cvv = cvv;

            DialogResult = true;
            Close();
        }

        private bool IsValidExpiryDate(string expiryDate)
        {
            if (!Regex.IsMatch(expiryDate, @"^(0[1-9]|1[0-2])/\d{2}$"))
            {
                return false;
            }

            string[] parts = expiryDate.Split('/');
            int month = int.Parse(parts[0]);
            int year = int.Parse(parts[1]) + 2000;

            DateTime now = DateTime.Now;
            DateTime expiry = new DateTime(year, month, 1).AddMonths(1).AddDays(-1);

            return expiry >= now;
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}