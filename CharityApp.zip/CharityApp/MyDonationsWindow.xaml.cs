﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using CharityApp.models;
using Microsoft.EntityFrameworkCore;

namespace CharityApp
{
    public partial class MyDonationsWindow : Window
    {
        private readonly User _user;

        public MyDonationsWindow(User user)
        {
            InitializeComponent();
            _user = user;
            LoadUserDonations();
        }

        private void LoadUserDonations()
        {
            List<Donation> donations;

            using (var context = new CharityDbContext())
            {
                donations = context.Donations
                                   .Include(d => d.Project)
                                   .Where(d => d.UserId == _user.Id)
                                   .OrderByDescending(d => d.Date)
                                   .ToList();
            }

            var donationList = donations.Select(d => new
            {
                Проект = d.Project?.Title ?? "Неизвестный проект",
                Сумма = $"{d.Amount:N2} BYN",
                Дата = d.Date.ToString("dd.MM.yyyy HH:mm")
            }).ToList();

            DonationsList.ItemsSource = donationList;
        }
    }
}
